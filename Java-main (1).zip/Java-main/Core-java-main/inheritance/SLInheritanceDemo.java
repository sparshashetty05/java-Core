package com.tnsif.inheritance;

public class SLInheritanceDemo {

	public static void main(String[] args) {		
		Student student = new Student(1,"DBIT", "Gayatri",123456789,"Bangalore",6364520807L);
		System.out.println(student);

	}
}
