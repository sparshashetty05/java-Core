package com.tnsif.exceptionhandling;


public class MultipleCatchDemo {

	public static void main(String[] args) {

		System.out.println("I am in main method");
		Division.divide();
	}
}